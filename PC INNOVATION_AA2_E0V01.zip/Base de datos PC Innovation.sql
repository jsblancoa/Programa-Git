select * from productos;
